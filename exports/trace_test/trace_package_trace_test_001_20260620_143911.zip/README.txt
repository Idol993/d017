熔断回滚完整链路包 - trace_test_001
==================================================
生成时间: 2026-06-20 14:39:11

回滚概要:
  状态:    completed
  版本:    2.0.0 -> 1.9.5
  时间:    2026-06-20T14:39:09.655658 ~ 2026-06-20T14:39:11.256766
  耗时:    1.6 秒
  步骤数:  4 步

文件清单:
  - [完整链路数据 (JSON, 含回滚信息)] trace_trace_test_001_20260620_143911.json
  - [监控明细 (CSV)] monitor_details_trace_test_001_20260620_143911.csv
  - [回滚步骤明细 (CSV)] rollback_steps_trace_test_001_20260620_143911.csv
  - [摘要报告 (Markdown)] trace_summary_trace_test_001_20260620_143911.md

使用说明:
  1. 先查看 summary_*.md 了解整体情况(含触发指标、趋势分析、回滚结果)
  2. trace_*.json 可用于程序化分析(完整结构化数据)
  3. monitor_details_*.csv 可导入 Excel 做透视分析
  4. rollback_steps_*.csv 可查看每一步回滚的执行细节(如有)

如有疑问请联系运维团队。